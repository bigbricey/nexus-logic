# Nexus Logic Premium Bundle v1.0

Thank you for your purchase. This bundle contains 5 premium MCP servers:

1. SEC Pulse
2. Scientific Sentinel
3. Local Lead Scraper
4. Social Sentiment
5. Biotech Intelligence

## Installation
For each server:
1. Navigate to the folder.
2. Run `npm install --production`.
3. Add the server to your Claude Desktop config or your preferred MCP client.

(c) 2026 Nexus Logic
