node build/index.js
